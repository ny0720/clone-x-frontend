const lines = 5;

for (let i=1; i<=lines; i++){
    let result = '';

    for (let j = 1; j<=lines-i; j++) {
        result += ' ';
    }

    for (let k=1; k<=2*i-1; k++){
        result += '*';
    }

    console.log(result);
}
